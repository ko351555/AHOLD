import React,{Component} from 'react';
import {AppRegistry, View, Text, TextInput, Button,StyleSheet,ScrollView} from 'react-native';
import { TabNavigator } from 'react-navigation';
import ScanToRefillComponent from './scanToRefill';
import ManagePrescriptionsComponent from './managePrescriptions/managePrescriptions'
import ManagePickUpListComponent from './managePickUpList'
import ManageFamilyComponent from './manageFamily'
import TransferComponent from './transfer'
import AlertsComponent from './alerts'
import {
  createNavigator,
  createNavigationContainer,
  TabRouter,
  addNavigationHelpers,
} from 'react-navigation';

const SubNavScreen = ({ navigation}) => (
  <ScrollView>
    <ScanToRefillComponent navigation={navigation} />
  </ScrollView>
);

const ScanToRefill = ({ navigation }) => (
  <SubNavScreen navigation={navigation} />
);
ScanToRefill.navigationOptions = {
  tabBarLabel: 'Scan To Refill',
};

const ManageFamily = ({ navigation }) => (
  <ManageFamilyComponent navigation={navigation} />
);
ManageFamily.navigationOptions = {
  tabBarLabel: 'Manage Family',
};

const ManagePrescriptions = ({ navigation }) => (
  <ManagePrescriptionsComponent navigation={navigation} />
);
ManagePrescriptions.navigationOptions = {
  tabBarLabel: 'Manage Prescriptions',
};

const ManagePickUpList = ({ navigation }) => (
  <ManagePickUpListComponent navigation={navigation} />
);
ManagePickUpList.navigationOptions = {
  tabBarLabel: 'Manage PickUpList',
};

const Transfer = ({ navigation }) => (
  <TransferComponent navigation={navigation} />
);
Transfer.navigationOptions = {
  tabBarLabel: 'Transfer',
};

const Alerts = ({ navigation }) => (
  <AlertsComponent navigation={navigation} />
);
Alerts.navigationOptions = {
  tabBarLabel: 'Alerts',
};

const CustomTabRouter = TabNavigator(
  {
    ScanToRefill: {
      screen: ScanToRefill,
      path:'Scan'
    },
    ManageFamily: {
      screen: ManageFamily,
      path:'Family'
    },
    ManagePrescriptions: {
      screen: ManagePrescriptions,
      path:'Pres'
    },
     ManagePickUpList: {
      screen: ManagePickUpList,
      path:'PickUp'
    },
     Transfer: {
      screen: Transfer,
      path:'Transfer'
    },
     Alerts: {
      screen: Alerts,
      path:'Notif'
    },
  },
  {
  tabBarPosition: 'top',
  swipeEnabled: false,
    animationEnabled: false,


  },

);

const styles = StyleSheet.create({
  container: {
    marginTop: 0,
  },
  tabContainer: {
    flexDirection: 'row',
    height: 48,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 4,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
  },
});


export default CustomTabRouter;
