import React,{Component} from 'react';
import {View,Text, StyleSheet,AsyncStorage} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'
import AddModal from './addModal'
import ManageModal from './manageModal'




export default class ManagePrescriptionsComponent extends Component{
	constructor(props) {
    super(props);
			this.state = {
name:''
				}

		}

componentDidMount()
{
this.getname();
}
		getname(){
		AsyncStorage.getItem('name', (err, result) => {

  		 console.log(result);
  		 this.setState({ name: result })

  	 });
}
  render() {
    return (
			<View>

			 <View style ={{flexDirection:'row', width: 350, paddingTop:10}}>
				 <View style ={{alignSelf:'flex-start', paddingBottom: 10, paddingLeft: 5 }}>
					 <Text style = {{fontSize: 20,}}>
						 Welcome back
					 </Text>
					 <Text style = {{fontSize: 25, color: 'purple'}}>
					{this.state.name} !
					 </Text>
				 </View>
				 <View style = {{ right: 0,position: 'absolute'}}>
				 <Icon
				 name='smile-o'

				 color='purple'
				 style = {{color:'purple',  size:30, paddingTop:20, paddingRight: 15,alignSelf: 'flex-end'}}/>


				 </View>
			 </View>
			<AddModal />
			<ManageModal />
</View>
    );
  }
}
