import React,{Component} from 'react';
import {AppRegistry, View, Text, TextInput, Button, ScrollView,StyleSheet, FlatList} from 'react-native';
import Axios from 'axios'
import { Card } from 'react-native-elements'

export default class ViewPrescriptions extends Component{
	constructor(props) {
    super(props);
			this.state = {
					medicine: '',
					Quantity:'',
					pharmacyNumber:'',
					image:'',
					prescriptionNumber:'',
					BuyingDate:'',
					userPrescriptions:[],

				}

		}

componentDidMount(){
  this.viewPrescription();
}


deleteprescription(pnum)  {
	console.log(pnum)

  Axios({
    method: 'delete',
    url: 'http://localhost:3000/delete',
    data:{
      prescriptionNumber: pnum
       }
  }).then(function(result){
		console.log(result);
		this.viewPrescription();
  }.bind(this))

}


viewPrescription() {

      let arr=[];
      Axios({
        method: 'post',
        url: 'http://localhost:3000/view',
        data:{
          userEmail: this.props.email
        }

      }).then(function(result){
        console.log(result)
        for(var i in result.data)
        {

        arr.push(result.data[i]);
        // console.log(arr)
        }
        this.setState({userPrescriptions:arr})
      // console.log(this.state.userPrescriptions)
      }.bind(this))
    }


    render() {
      return (
    <View>
                {this.state.userPrescriptions.map((u, i) => {
                  return(
                    <Card title="Prescription details"  key={i}>

                          <View  >
                        <Text >{u.userEmail}</Text>
                        <Text >{u.BuyingDate}</Text>
                            <Text >{u.Medicine}</Text>
                            <Text >{u.Quantity}</Text>
                            <Text >{u.PharmacyNumber}</Text>

                            <Text >{u. image}</Text>

                            <Text >{u.PrescriptionNumber}</Text>

                          </View>

													<View style={{padding:10}}>
													<Button
												  onPress={()=>{this.deleteprescription(u.PrescriptionNumber)}}
												  title="Delete"
												  color="#841584"
												/>
													</View>
											

                    </Card>
                  )

              })}

            </View>

      );
    }
    }
