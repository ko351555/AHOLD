import React,{Component} from 'react';
import {AppRegistry, View, Text, TextInput, Button, ScrollView,StyleSheet, FlatList} from 'react-native';
import Axios from 'axios'

export default class AddPrescription extends Component{
	constructor(props) {
    super(props);
			this.state = {
					medicine: '',
					Quantity:'',
					pharmacyNumber:'',
					image:'',
					prescriptionNumber:'',
					BuyingDate:'',
					userPrescriptions:[],

				}

		}

    handlePrescription = () =>{
			console.log(this.props.userEmail)
			var d = new Date(),
     		minutes = d.getMinutes().toString().length == 1 ? '0'+d.getMinutes() : d.getMinutes(),
    		hours = d.getHours().toString().length == 1 ? '0'+d.getHours() : d.getHours(),
    		ampm = d.getHours() >= 12 ? 'pm' : 'am',
    		months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
    		days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
			var n= days[d.getDay()]+' '+months[d.getMonth()]+' '+d.getDate()+' '+d.getFullYear()+' '+hours+':'+minutes+ampm;
				this.setState({BuyingDate:n})
				console.log('register')
		    Axios({
			    method: 'POST',
			    url: 'http://localhost:3000/add',
			    data:{
			    medicine:this.state.medicine,
			    Quantity:this.state.Quantity,
			    pharmacyNumber:this.state.pharmacyNumber,
			    image:this.state.image,
					prescriptionNumber:this.state.prescriptionNumber,
					userEmail:this.props.email,
					BuyingDate:n
		    }
		    }).then(function (response) {
		    	 console.log(response);
		    }.bind(this))
		}


    render() {
      return (
  <View>


  				<Text >Medicine</Text>

  			<TextInput
  				style={{height: 40, width:310,marginBottom:10}}
  			// placeholder="Enter your name"
  			 underlineColorAndroid='white'
  				onChangeText={(medicine) => this.setState({medicine})} />

  					<Text >Quantity</Text>
  			<TextInput
  				style={{height: 40, width:310,backgroundColor:'white',marginBottom:10}}
  			//  placeholder="Enter your mail-id"
  				underlineColorAndroid='white'
  				onChangeText={(Quantity) => this.setState({Quantity})} />

  				<Text>pharmacyNumber</Text>
  				<TextInput
  					style={{height: 40, width:310,backgroundColor:'white',marginBottom:10}}
  					//placeholder="Enter your password"
  				secureTextEntry={true}
  				underlineColorAndroid='white'
  					onChangeText={(pharmacyNumber) => this.setState({pharmacyNumber})} />

  					<Text >image</Text>
  					<TextInput
  					style={{height: 40, width:310,backgroundColor:'white',marginBottom:20}}
  						//placeholder="Enter your phone number"
  						secureTextEntry={true}
  						underlineColorAndroid='white'
  						onChangeText={(image) => this.setState({image})} />
  						<Text >prescriptionNumber</Text >
  						<TextInput
  						style={{height: 40, width:310,backgroundColor:'white',marginBottom:20}}
  							underlineColorAndroid='white'
  							onChangeText={(prescriptionNumber) => this.setState({prescriptionNumber})} />
  							<View style={{padding:10}}>
  							<Button
  							  onPress={this.handlePrescription}
  							  title="Submit"
  							  color="#841584"
  							/>

  							</View>


  					</View>

      );
    }
  }
