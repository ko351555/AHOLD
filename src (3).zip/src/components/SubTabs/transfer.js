import React,{Component} from 'react';
import {AppRegistry, View, Text, TextInput, Button, ScrollView,StyleSheet, FlatList} from 'react-native';
import Axios from 'axios'


export default class TransferComponent extends Component{
	constructor(props) {
    super(props);
			this.state = {

				}

		}


  render() {
    return (
<View>



					<Text >TransferComponent</Text>

					</View>

    );
  }
}
