import React, { Component } from 'react';
import { Text, View, StyleSheet, Button,Image } from 'react-native';

export default class OurNutrionists extends Component {
  render() {
    return (
      <View
      style={styles.container}
      >
      <Image resizeMode='stretch'
      source={require('./nutritionist.jpg')}

        >
          <Text style={styles.textTitle}>Our Nutritionists </Text>
          <View  style={styles.viewParagraph}>
              <Text
              style={styles.textParagraph}
              >
              Put your health in good hands with our nutritionists.
              They are here to help you and your family stay well and make better food choices.
              Look for them as your shop,attend a class, or svhedule a private consultation to discuss your nutritional needs.

             </Text>
            <View style={styles.buttonView}>
                <Button
                icon={{name: 'code'}}
                color='purple'
                fontFamily='Lato'

                title='Get to know our nutritionists' />
            </View>
        </View>
         </Image>

      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    marginBottom: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textTitle: {
    marginBottom: 200,
    fontSize: 18,
    fontWeight: 'bold',
    color: '#34495e',
    backgroundColor: 'rgba(163, 125, 171, 0.8)',

  },
  textParagraph:{
      fontSize: 8,
      color: 'rgb(254, 254, 254)',
      alignItems: 'center',
      justifyContent: 'center',
      },
  viewParagraph:{
      backgroundColor: 'rgba(1,1,1, 0.6)',
  },
  buttonView:{
     padding:10
  }
});
