import React, { Component } from 'react';
import { Text, View, StyleSheet, Button,Image } from 'react-native';

export default class HealthyKids extends Component {
  render() {
    return (
      <View
      style={styles.container}
      >
      <Image
      resizeMode='contain'
        source={require('./smilingkids.jpg')}
        >
          <View style={styles.viewTitle}>
          <Text style={styles.textTitle}>Healthy Kids </Text>
          </View>
          <View  style={styles.viewParagraph}>
              <Text
              style={styles.textParagraph}
              >
              Put your health in good hands with our nutritionists.
              They are here to help you and your family stay well and make better food choices.
              Look for them as your shop,attend a class, or svhedule a private consultation to discuss your nutritional needs.

             </Text>
             </View>
            <View style={styles.buttonView}>
                <Button
                icon={{name: 'code'}}
                color='purple'
                fontFamily='Lato'
                title='Learn more' />
            </View>

         </Image>
       </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    paddingBottom: 24,
    marginBottom: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textTitle: {
    // marginBottom: 150,
    marginLeft:10,
    fontSize: 18,
    color: 'white',
    // backgroundColor: 'rgba(163, 125, 171, 0.8)',

  },
  textParagraph:{
      fontSize: 8,
      marginLeft:10,
      color: 'white',
      },
  viewParagraph:{
      backgroundColor: 'rgba(1,1,1, 0.6)',
      marginBottom:150,
  },
  viewTitle:{
      backgroundColor: 'rgba(163, 125, 171, 0.8)',
  },
  buttonView:{
     padding:5,
  }
});
//https://www.destinyusa.com/wp-content/uploads/sites/7/2016/04/Smiling-kids-showing-their-healthy-teeth.jpg
