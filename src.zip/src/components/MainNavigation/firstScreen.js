import React from 'react'
import {View,Text} from 'react-native'
import SubScreenNavigator from './SubNavigation/subNavigationScreen'

export default class FirstScreen extends React.Component{
	static navigationOptions={
		tabBarLabel: 'Tab1'
	}
	render(){
		return(
			<View>
			<Text>'Hrsgknsbv'</Text>
			</View>
			

			)
	}
}
