  import React from 'react';
import { View,Button, Platform, ScrollView, StyleSheet,AppRegistry,Text,TouchableOpacity } from 'react-native';
import { DrawerNavigator } from 'react-navigation';

//import SampleText from './SampleText';
const Dimensions = require('Dimensions');

const window = Dimensions.get('window');

const MyNavScreen = ({ navigation, banner }) => (

  <ScrollView style={styles.container}>
    <View style={styles.header}>
      <View style ={{flex:1,alignItems:'center',justifyContent :'center'}}>
      <TouchableOpacity onPress={() => navigation.navigate('DrawerOpen')}>

      </TouchableOpacity>
      </View>
      <View style ={{flex:4,alignItems:'center'}}>
      </View>
    </View>
    <View style={styles.body}>
    <Button
      onPress={() => navigation.navigate('DrawerOpen')}
      title="Sign In"
    />
    <Button onPress={() => navigation.goBack(null)} title="Register" />
    </View>
    <Text>{banner}</Text>

  </ScrollView>
);

const InboxScreen = ({ navigation }) => (
  <MyNavScreen banner={'Inbox Screen'} navigation={navigation} />
);
InboxScreen.navigationOptions = {
  drawerLabel: 'Sign In',

  headerMode: 'none'
};

const DraftsScreen = ({ navigation }) => (
  <MyNavScreen banner={'Drafts Screen'} navigation={navigation} />
);
DraftsScreen.navigationOptions = {
  drawerLabel: 'Drafts',
  
  headerMode: 'none'
};

const awe = DrawerNavigator(
  {
    Inbox: {
      path: '/',
      screen: InboxScreen,
    },
    Drafts: {
      path: '/sent',
      screen: DraftsScreen,
    },
  },
  {
    initialRouteName: 'Drafts',
    contentOptions: {
      activeTintColor: '#e91e63',
    },

  }
);

const styles = StyleSheet.create({
  container: {
    flex : 1,
    flexDirection : 'row'
  },
  header : {
    flex : 1,
    backgroundColor : '#660066',
    width : Dimensions.get('window').width,
    flexDirection : 'row'
  },
  body : {
    flex : 7,

  }


});
export default awe;
