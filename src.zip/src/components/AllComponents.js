import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TouchableHighlight,
  TouchableOpacity,
  ScrollView,
  Platform
} from 'react-native';
import {TabNavigator } from 'react-navigation';
import MainComponents from './MainComponents'
import Register from './Register'
import WeekProgress from '../components/Notification/WeekProgress';
//import CustomTabRouter from '../components/SubTabs/navigationScreen';
import MediaryTabNavigation from './mediaryTabNavigation';
import SearchHistory from '../components/search/history';
import Wellness from './WellnessTab/wellness'

const MyNavScreen = ({ navigation}) => (
<ScrollView >
    <MediaryTabNavigation   />
  </ScrollView>
);

const PharmacyScreen = ({ navigation }) => (
  <MyNavScreen  navigation={navigation} />
);

PharmacyScreen.navigationOptions = {
  tabBarLabel: 'Pharmacy',
};

const WellnessScreen = ({ navigation }) => (
  <Wellness navigation={navigation} />
);

WellnessScreen.navigationOptions = {
  tabBarLabel: 'Wellness',
};

const FindStoreScreen = ({ navigation }) => (
  <SearchHistory navigation={navigation} />
);

FindStoreScreen.navigationOptions = {
  tabBarLabel: 'Find a store',
};

const AlarmScreen = ({ navigation }) => (
  <WeekProgress navigation={navigation} />
);

AlarmScreen.navigationOptions = {
  tabBarLabel: 'Alarm',
};

const AllComponents = TabNavigator(
  {
    Pharmacy: {
      screen: PharmacyScreen,
      path: 'chats',

    },
    Wellness: {
      screen: WellnessScreen,
      path: 'cart',
    },
    FindStore: {
      screen: FindStoreScreen,
      path: 'chat',
    },
    Alarm: {
      screen: AlarmScreen,
      path: 'chats',
    },

  },

);

const styles = StyleSheet.create({


});

export default AllComponents;
