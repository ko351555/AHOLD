import React, {Component} from 'react';
import {ScrollView, View, TextInput, Text, TouchableOpacity, } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'

export default class SearchHistory extends Component{
  render() {
    return (
      <ScrollView>

      <TouchableOpacity >

      <View>
      <Icon style={{padding:20}}
      name='search'
      size={15}
        />
      <TextInput
        style={{height: 40,width:200,backgroundColor:'white'}}
        placeholder ="Search for items"
        underlineColorAndroid='white'
         />
         </View>
      </TouchableOpacity>

      </ScrollView>
    )
  }
}
