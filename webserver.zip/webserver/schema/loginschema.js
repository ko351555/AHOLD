var mongoose=require('mongoose');
const bcrypt = require('bcrypt-nodejs');

var Schema=mongoose.Schema;
var loginSchema=new Schema({
  username : String,
  password: String
});
loginSchema.methods.validPassword = function( pwd ) {
  return ( this.password === pwd );
};



module.exports=mongoose.model('logindetails',loginSchema);
