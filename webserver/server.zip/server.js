var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var app = express();
var User=require('../webserver/schema/loginschema.js');
var Signup=require('../webserver/schema/signupschema.js');
var prescription = require('../webserver/schema/prescriptionSchema');

var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var session = require('express-session');


app.use(session({ secret: 'keyboard cat',proxy: true,
   resave: true,
   saveUninitialized: true}));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use('/', express.static(path.join(__dirname, './webclient/')));

//Authentication

app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(
  function(username, password, done) {
    Signup.findOne({ username: username }, function(err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (!user.validPassword(password)) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      return done(null, user);
    });
  }
));
passport.serializeUser(function(user, done) {
  //console.log(user._id);
  done(null, user);
});

passport.deserializeUser(function(id, done) {
 //console.log("deserializeUser")
  Signup.findById(id, function(err, user) {
    done(err, user);
  });
});




app.post('/signup',function(req,res,next)
{
  var Signup= new Signup(
    {
      username:req.body.username,
      password:req.body.password,
      phoneno:req.body.phoneno,
      email:req.body.email
    })

    Signup.save(function(error,data)
  {
    res.send(data)

    if(error)
    {
      console.log(error)
    }
  })
})


passport.use(new LocalStrategy(
  function(username, password, done) {
    Signup.findOne({ username: username }, function (err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (!user.validPassword(password)) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      return done(null, user);
    });
  }
));


app.post('/add',function(req,res){


	console.log(req.body)
var Pres = new prescription({
	Medicine : req.body.medicine,
	Quantity : req.body.Quantity,
	PrescriptionImage :req.body.image,
	PharmacyNumber : req.body.pharmacyNumber,
	PrescriptionNumber : req.body.prescriptionNumber,
  BuyingDate:req.body.BuyingDate,
  userEmail:req.body.userEmail
});

Pres.save(function(error,data) {
     console.log("Your bee has been saved!");
     res.send(data)
 if (error) {
    console.error(error);  }
 });
});


 app.post('/view',function(req, res){

   prescription.find({userEmail:req.body.userEmail},function(err,data){
     res.send(data)
     if(err){
        console.error(err)
     }
   });
 });
 app.delete('/delete',function(req, res){

   prescription.remove({PrescriptionNumber:req.body.PrescriptionNumber},function(err,data){
     if(err)
       res.send({'success':'Not deleted'});
     else {
       res.send({'success':'deleted'});
     }
   });
 });

// app.post('/logout',function(req,res,next){
//   req.session.destroy();
//   res.send('success');
// })
// app.post('/signup',function(req,res,next){
//   req.session.destroy();
//   res.send('success');
// })
//
//
// app.get('/login',function(req,res,next){
//   res.send('failure login');
// });
// app.get('/success',function(req,res,next){
//   console.log('sajhcaksjch')
//
//   res.send('success login');
// });


//Mongoose
var db = 'mongodb://localhost/androidapp';
mongoose.connect(db);

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
    console.log("connected with mongo");
});








//Listening to port 8080
app.listen(3000, '0.0.0.0', function(err, result) {
    if (err) {
        console.error("Error ", err);
    }
    console.log("Server started at 3000");
});
